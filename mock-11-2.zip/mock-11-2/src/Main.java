import java.text.ParseException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name of the University:");
		String universityName = sc.nextLine();
		University university = new University();
		university.setName(universityName);

		do {
			System.out.println("Enter your choice:");
			System.out.println(
					"1.Add College \r\n" + "2.Delete College \r\n" + "3.Display Colleges \r\n" + "4.Exit \r\n" + "");
			int choice = sc.nextInt();
			switch (choice) {
			case 1: // add college
				String input = sc.nextLine();
				if (input.equals(""))
					input = sc.nextLine();
				College college = College.createCollege(input);
				university.addCollegeToUniversity(college);
				System.out.println("College successfully added");
				break;
			case 2: // delete college
				String collegeName = sc.nextLine();
				if (collegeName.equals(""))
					collegeName = sc.nextLine();
				Boolean status = university.removeCollege(collegeName);
				if(status)
				{
					System.out.println("College successfully deleted");
				}else
				{
					System.out.println("College not found in the University");
				}
				break;
			case 3: // display colleges
				university.displayColleges();
				break;
			case 4: // exit
				System.exit(0);
				break;
			}
		} while (true);
	}
}
