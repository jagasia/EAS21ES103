import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.Types;

public class App {

	public static void main(String[] args) throws SQLException {
		int eid=111;
		String fname="";
		int sal=0;
		Driver driver=new oracle.jdbc.driver.OracleDriver();
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		CallableStatement st = con.prepareCall("{ call PRC1(?,?,?)}");
		st.setInt(1, eid);
		st.registerOutParameter(2, Types.VARCHAR);
		st.registerOutParameter(3, Types.INTEGER);
		st.execute();
		
		System.out.println(st.getString(2));
		System.out.println(st.getInt(3));
	}

}
