
public class App_Casting {

	public static void main(String[] args) {
		//casting between data types
		//	a=b;			if both a and b are same type, no need to cast
		//	a=b;			a is larger than b and compatible, then no need to cast		(implict)
		//	a=b;			a is smaller than b then explicit casting is required
		
		int a=20;
		long b=30;
//		a=b;			error
		a=(int) b;			//casting			what is the type in left side? that type is in casting
		
		b=a;				//implicit casting. 
		b=(long)a;			//in old versions, we were doing this explicit casting
	
		
		//casting between objects
		//left side is the target. and if target is super type and it is implicit casting
		Furniture f=new Chair();			//implicit casting
		Chair c=(Chair) f;							//explicit casting
		
		
	}

}
