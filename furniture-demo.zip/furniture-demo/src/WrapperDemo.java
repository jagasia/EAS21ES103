
public class WrapperDemo {

	public static void main(String[] args) {
		int i=20;		
		//i want to store the largest possible value in int
		i=Integer.MAX_VALUE;
		System.out.println(i);
		//mobile numbers cannot be stored in "int" type because 10 digits are allowed. 
		//but first digit is 2		not "9"
		
		
		long l=0;
		l=Long.MAX_VALUE;
		System.out.println(l);
		
		Integer.parseInt("123");			//returns 	int
		Integer.valueOf("121");				//returns 	Integer
		String.valueOf(20);					//returns 	String	"20"
		
		//in versions before 1.5, converting primitives to wrapper was not automatic
		//now that boxing is automatic
		//converting primitive to wrapper is called as boxing
		
		int age=20;
		Integer x=age;				//auto boxing		int =>	Integer
		int y=x;					//auto unboxing		Integer=>	int
		
		
		
	}

}
