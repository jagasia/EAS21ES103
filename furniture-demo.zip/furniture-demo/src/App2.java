import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class App2 {

	public static void display2() throws FileNotFoundException
	{
		FileInputStream fis=new FileInputStream("");
	}
	
	public static void display()
	{
		int i=20;
		int j=0;
		
		System.out.println("No issues: "+(i/j));
	}
	public static void main(String[] args){
		display();
		try {
			display2();
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(Exception e)
		{
			//this will handle any exception of type Exception class or its sub class
			//because, Exception is the super class for all exception classes
		}
		
		
	}

}
