import java.util.Scanner;

public class Chair extends Furniture
{
	private int noOfLegs;
	
	public Chair() {}

	public Chair(int noOfLegs) {
		super();
		this.noOfLegs = noOfLegs;
	}

	public int getNoOfLegs() {
		return noOfLegs;
	}

	public void setNoOfLegs(int noOfLegs) {
		this.noOfLegs = noOfLegs;
	}

	@Override
	public void acceptDetails() {
		// TODO Auto-generated method stub
		super.acceptDetails();
		Scanner sc=new Scanner(System.in);
		System.out.println("No of legs:");
		this.noOfLegs=sc.nextInt();
	}

	@Override
	public void displayDetails() {
		// TODO Auto-generated method stub
		super.displayDetails();
		System.out.println("No of legs:"+this.noOfLegs);
	}
	
//	public void acceptDetails()
//	{
//		super.acceptDetails();
//		Scanner sc=new Scanner(System.in);
//		System.out.println("No of legs:");
//		this.noOfLegs=sc.nextInt();
//	}
//	
//	public void displayDetails()
//	{
//		super.displayDetails();
//		System.out.println("No of legs:"+this.noOfLegs);
//	}
	
	
}
