import java.util.Scanner;

public class App {

	public static void main(String[] args) {
		Furniture f;
		Scanner sc=new Scanner(System.in);
		System.out.println("What do you want to purchase?");
		System.out.println("1: Chair\r\n" + 
				"2: BookSelf\r\n" + 
				"3: Exit\r\n" + 
				"");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			f=new Chair();
			break;
		case 2:
			f=new BookShelf();
			break;
		default:
			System.out.println("Invalid choice.");
			return;			//return from main method means. exit		System.exit(0);
		}
		
		f.acceptDetails();
		f.displayDetails();
		
	}

}
