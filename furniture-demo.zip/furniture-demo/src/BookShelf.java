import java.util.Scanner;

public class BookShelf extends Furniture
{
	private int noOfShelves;
	
	public BookShelf() {}

	public BookShelf(int noOfShelves) {
		this.noOfShelves = noOfShelves;
	}

	public int getNoOfShelves() {
		return noOfShelves;
	}

	public void setNoOfShelves(int noOfShelves) {
		this.noOfShelves = noOfShelves;
	}
	
	public void acceptDetails()
	{
		super.acceptDetails();		
		Scanner sc=new Scanner(System.in);		
		System.out.println("No of shelves:");
		this.noOfShelves=sc.nextInt();
	}
	
	public void displayDetails()
	{
		super.displayDetails();
		System.out.println("No of shelves:"+this.noOfShelves);
	}
}
