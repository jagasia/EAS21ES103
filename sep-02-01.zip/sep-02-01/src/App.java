import java.util.Arrays;

public class App {

	public static void main(String[] args) {
		int arr[]={55,100,34,21,46,89,74,20};
		
		for(int x:arr)
		{
			System.out.println(x);
		} 
	}

}
