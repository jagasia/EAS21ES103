import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		HashSet<Integer> marks=new HashSet<>();
		marks.add(100);	
		marks.add(50);
		marks.add(0);
		marks.add(50);		//duplicate
		marks.add(88);
		marks.add(34);
		marks.add(83);
		marks.add(50);		//duplicate
		marks.add(19);
		
		System.out.println(marks);
	}

}
