package com.cts.hrms;

public class Employee {
	public static void main(String[] args) {
		int arr[][]= {
				{11,22,33,44},
				{100,200},
				{8,9,10,11,12},
				{500,501,502,503,504,505}
		};
		
		//how to loop all these values???
		for(int i=0;i<arr.length;i++)		//arr.length is no of rows
		{
			for(int j=0;j<arr[i].length;j++)	//arr[i].length is no of cols
			{
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
}
