import java.util.Scanner;

public class LastCharacter {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int noOfElements=sc.nextInt();
		char []arr=new char[noOfElements];			//in java we can do this		
		
		for(int i=0;i<noOfElements;i++)
		{
			arr[i]=sc.next().charAt(0);
		}
		char result='\0';
		int n;
		n=sc.nextInt();
		
		for(int i=0;i<noOfElements;i++)
		{
			int count=0;			//reset to 0 for each character to begin with
			for(int j=0;j<noOfElements;j++)
			{
				if(arr[i]==arr[j])
				{
					count++;
				}
			}
			//check the count if it is equal to n
			if(count==n)
			{
				result=arr[i];
			}
		}
		if(result=='\0')
			System.out.println(-1);
		else
			System.out.println(result);
	}

}
