import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		Integer age=20;			//auto boxing
		int i=age;				//auto unboxing
		
		
		ArrayList<Integer> marks=new ArrayList<Integer>();
		marks.add(100);	//expecting an Integer. we gave an int. it was auto boxed
		marks.add(50);
		marks.add(0);
		marks.add(50);
		marks.add(88);
		marks.add(34);
		marks.add(83);
		marks.add(50);
		marks.add(19);
		
//		marks.remove(0);				// 0 is index
//		marks.remove(new Integer(0));	// 0 is an object 
//		
		
		System.out.println(marks);
		Collections.sort(marks);
		System.out.println(marks);
//		System.out.println(marks.get(0));
//		System.out.println(marks.get(1));
//		System.out.println(marks.get(2));
//		System.out.println(marks.get(3));
//		
	}

}
