import java.util.Scanner;

public class App2 {

	public static void main(String[] args) {
		int sno;
		String name;
		float marks;
		
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		sno=sc.nextInt();		
		name=sc1.nextLine();
		
		marks=sc.nextFloat();
		
		System.out.println(sno);
		System.out.println(name);
		System.out.println(marks);
		
	}

}
