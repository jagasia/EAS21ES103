package com.cts.hrms.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;

public class App3 {

	public static void main(String[] args) {
//		ArrayList<Employee> employeeSet=new ArrayList<>();
//		HashSet<Employee> employeeSet = new HashSet<>();
		TreeSet<Employee> employeeSet = new TreeSet<>(new EmployeeSalaryComparator());
		employeeSet.add(new Employee(1, "Rama", "Krishna", 123456.0));
		employeeSet.add(new Employee(22, "Abdul", "Raheem", 191919.0));
		employeeSet.add(new Employee(32, "Rama", "Rajan", 373737.0));
		employeeSet.add(new Employee(1, "Suresh", "Krishna", 182736.0));
		employeeSet.add(new Employee(53, "Suresh", "Raina", 92929.0));
		employeeSet.add(new Employee(36, "Zaheer", "Khan", 161514.0));
		employeeSet.add(new Employee(1, "Suresh", "Peters", 123256.0));
		employeeSet.add(new Employee(84, "John", "Peters", 22222.0));
		employeeSet.add(new Employee(1, "Radha", "Krishna", 232312.0));
		
//		Collections.sort(employeeSet);			//sort is not possible in a Set
		
		for(Employee e:employeeSet)
		{
			System.out.println(e);
		}
	}

}
