package com.cts.hrms.model;

import java.util.Comparator;

public class EmployeeSalaryComparator implements Comparator<Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o2.getSalary().compareTo(o1.getSalary());
	}

}
