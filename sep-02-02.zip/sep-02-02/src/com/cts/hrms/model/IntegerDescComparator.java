package com.cts.hrms.model;

import java.util.Comparator;
import java.util.TreeSet;

public class IntegerDescComparator implements Comparator<Integer>
{

	@Override
	public int compare(Integer o1, Integer o2) {
//		return o2-o1;
		return o2.compareTo(o1);
	}

	public static void main(String[] args) {
		TreeSet<Integer> marks=new TreeSet<Integer>(new IntegerDescComparator());
		marks.add(11);
		marks.add(55);
		marks.add(22);
		marks.add(121);
		marks.add(211);
		marks.add(112);
		marks.add(21);
		marks.add(13);
		marks.add(35);
		for(Integer m:marks)
			System.out.println(m);
	}
}
