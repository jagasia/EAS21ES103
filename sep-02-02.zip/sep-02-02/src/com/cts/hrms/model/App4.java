package com.cts.hrms.model;

import java.util.TreeSet;

public class App4 {

	public static void main(String[] args) {
		TreeSet<Integer> marks=new TreeSet<Integer>((a,b)->b-a);
		marks.add(11);
		marks.add(55);
		marks.add(22);
		marks.add(121);
		marks.add(211);
		marks.add(112);
		marks.add(21);
		marks.add(13);
		marks.add(35);
		for(Integer m:marks)
			System.out.println(m);
	}
}
