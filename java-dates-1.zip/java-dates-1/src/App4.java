import java.text.SimpleDateFormat;
import java.util.Date;

public class App4 {

	public static void main(String[] args) {
		SimpleDateFormat sdf=new SimpleDateFormat("EEE");	//week day of a date
		Date dt=new Date();
		System.out.println(sdf.format(dt));
	}

}
