import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class App2 {

	public static void main(String[] args) throws ParseException {
		String str="1999-01-01";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date dob1=sdf.parse(str);
		java.sql.Date dob2=new java.sql.Date(dob1.getTime());
		LocalDate dob3 = dob2.toLocalDate();
		
		LocalDate today=LocalDate.now();
		
		System.out.println(dob3);
		System.out.println(today);
		Period result = Period.between(dob3, today);
		System.out.printf("You are %d Years, %d Months and %d days old",result.getYears(),result.getMonths(),result.getDays());
	}

}
