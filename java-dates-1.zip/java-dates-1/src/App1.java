import java.time.LocalDate;
import java.util.Date;

public class App1 {

	public static void main(String[] args) {
		Date dt=new Date();
		System.out.println(dt);
		//to get this date as a long value
		System.out.println(dt.getTime());
		//
		
		dt.setTime(-100000000000000L);
		System.out.println(dt);
		
		/////
		
		
		java.sql.Date dt1=new java.sql.Date(dt.getTime());
		System.out.println(dt1);
		
		//from java.sql.Date we can convert it into LocalDate
		
		LocalDate dt2 = dt1.toLocalDate();
		
		
	}

}
