import java.util.Date;
import java.util.GregorianCalendar;

public class App3 {

	public static void main(String[] args) {
		GregorianCalendar gc=new GregorianCalendar();
		System.out.println(gc.isLeapYear(2024));
		gc.set(2021, 1, 6);
		System.out.println(gc.getTime());
		
		Date dt=new Date();
		System.out.println(dt.getYear());
		System.out.println(dt.getMonth());
	}

}
