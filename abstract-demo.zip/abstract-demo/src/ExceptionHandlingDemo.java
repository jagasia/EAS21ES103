import java.io.IOException;

public class ExceptionHandlingDemo {

	public static void main(String[] args) {
		try
		{
			int i=20;
			int j=30;
			int k=40;
			j=0;
			k=i/j;
			System.out.println(k);
		}catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("This is finally block");
		}
		System.out.println("The program continues");
	}

}
