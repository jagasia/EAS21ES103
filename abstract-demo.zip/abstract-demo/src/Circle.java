public class Circle extends Shape
{
	float radius;
	public float calculateArea()
	{
		return 22/7 * radius * radius;
	}
}
