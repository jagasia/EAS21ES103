
public class App {

	public static void main(String[] args) {
		Shape s;				// s is not an object. It is just ref variable		null
		s=new Triangle(10, 10);		//s is an object of Triangle
		
		float result = s.calculateArea();
		System.out.println(result);
	}

}
