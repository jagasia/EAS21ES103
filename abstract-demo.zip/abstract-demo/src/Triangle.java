public class Triangle extends Shape
{
	float breadth;
	float height;
	
	public Triangle() {}
	
	
	public float getBreadth() {
		return breadth;
	}


	public void setBreadth(float breadth) {
		this.breadth = breadth;
	}


	public float getHeight() {
		return height;
	}


	public void setHeight(float height) {
		this.height = height;
	}


	public Triangle(float breadth, float height) {
		super();
		this.breadth = breadth;
		this.height = height;
	}


	public float calculateArea()
	{
		return 0.5f * breadth * height;
	}
}
