public class Rectangle extends Shape
{
	float length;
	float breadth;
	public float calculateArea()
	{
		return length * breadth;	
	}
}
