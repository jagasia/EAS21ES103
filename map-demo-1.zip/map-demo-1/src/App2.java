import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class App2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		
		Map<Character, Integer> result=new TreeMap<>();
		
		for(char c:input.toCharArray())
		{
			int count=0;
			Integer x = result.get(c);
			if(x!=null)
				count=x;
			count++;
			
			result.put(c, count);
		}
		
//		/display result
		
		for(Entry<Character, Integer> entry:result.entrySet())
			System.out.println(entry);
	}

}
