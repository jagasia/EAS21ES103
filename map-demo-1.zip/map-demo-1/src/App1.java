import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class App1 {

	public static void main(String[] args) {
		HashMap<Integer, String> countries=new HashMap<>();
		countries.put(10, "India");
		countries.put(110, "Australia");
		countries.put(null, "Srilanka");
		countries.put(210, "Kuwait");
		countries.put(120, "Argentina");
		countries.put(null, "Zimbabwe");
		countries.put(310, "Japan");
		countries.put(130, "China");
		countries.put(103, "Pakistan");
		countries.put(103, "Bangladesh");
		
//		System.out.println(countries);
		
//		for(Entry<Integer, String> entry:countries.entrySet())
//		{
//			System.out.println(entry.getKey()+" : "+entry.getValue());
//		}

//		Set<Entry<Integer, String>> entries = countries.entrySet();
//		Iterator<Entry<Integer, String>> it = entries.iterator();
//		while(it.hasNext())
//		{
//			Entry<Integer, String> entry = it.next();
//			System.out.println(entry.getKey()+" : "+entry.getValue());
//		}
//	
		
			Set<Integer> keys = countries.keySet();
			Iterator<Integer> it = keys.iterator();
			while(it.hasNext())
			{
				Integer key = it.next();
				System.out.println(key+" : "+countries.get(key));
			}
		
	}

}
