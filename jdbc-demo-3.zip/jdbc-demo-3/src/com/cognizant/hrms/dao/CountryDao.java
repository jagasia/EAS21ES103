package com.cognizant.hrms.dao;

import java.sql.SQLException;
import java.util.List;

import com.cognizant.hrms.entity.Country;

public interface CountryDao {

	int create(Country country) throws SQLException, ClassNotFoundException;

	List<Country> read() throws SQLException, ClassNotFoundException;

	int update(Country country) throws SQLException, ClassNotFoundException;

	int delete(String countryId) throws SQLException, ClassNotFoundException;

	Country read(String countryId) throws SQLException, ClassNotFoundException;

}