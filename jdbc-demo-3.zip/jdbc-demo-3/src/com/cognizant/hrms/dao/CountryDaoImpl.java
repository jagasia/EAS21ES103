package com.cognizant.hrms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.cognizant.hrms.entity.Country;

public class CountryDaoImpl implements CountryDao {
	
	private Connection getConnection() throws SQLException, ClassNotFoundException
	{
		ResourceBundle rb = ResourceBundle.getBundle("db");				//db means, db.properties
		String driverClassName=rb.getString("driver");
		String url=rb.getString("url");
		String username=rb.getString("username");
		String password=rb.getString("password");
		
//		Driver driver=new oracle.jdbc.driver.OracleDriver();
		Class.forName(driverClassName);			//we can create object of a class whose class name is in string		
		return DriverManager.getConnection(url,username,password);
	}
	
	@Override
	public int create(Country country) throws SQLException, ClassNotFoundException
	{
		Connection con = getConnection();
		String sql="INSERT INTO COUNTRIES VALUES(?,?,?)";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, country.getCountryId());
		st.setString(2, country.getCountryName());
		st.setInt(3, country.getRegionId());
		
		int no=st.executeUpdate();
		return no;
	}
	@Override
	public List<Country> read() throws SQLException, ClassNotFoundException
	{
		Connection con = getConnection();
		String sql="SELECT * FROM COUNTRIES";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		List<Country> countryList=new ArrayList<>();
		while(rs.next())
		{
			Country country=new Country(rs.getString(1),rs.getString(2),rs.getInt(3));
			countryList.add(country);
		}
		return countryList;
	}
	@Override
	public int update(Country country) throws SQLException, ClassNotFoundException
	{
		Connection con = getConnection();
		String sql="UPDATE COUNTRIES SET COUNTRY_NAME=?, REGION_ID=? WHERE COUNTRY_ID=?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, country.getCountryName());
		st.setInt(2, country.getRegionId());
		st.setString(3, country.getCountryId());
		
		int no=st.executeUpdate();
		return no;
	}
	@Override
	public int delete(String countryId) throws SQLException, ClassNotFoundException
	{
		Connection con = getConnection();
		String sql="DELETE FROM COUNTRIES WHERE COUNTRY_ID=?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, countryId);
		
		return st.executeUpdate();
	}
	@Override
	public Country read(String countryId) throws SQLException, ClassNotFoundException
	{
		Connection con = getConnection();
		String sql="SELECT * FROM COUNTRIES WHERE COUNTRY_ID=?";
		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, countryId);
		
		ResultSet rs = st.executeQuery();
		Country country=null;
		if(rs.next())
		{
			country=new Country(rs.getString(1),rs.getString(2),rs.getInt(3)); 
		}
		return country;
	}
	
}
