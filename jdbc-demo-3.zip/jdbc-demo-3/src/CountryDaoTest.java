import java.sql.SQLException;

import com.cognizant.hrms.dao.CountryDao;
import com.cognizant.hrms.dao.CountryDaoImpl;
import com.cognizant.hrms.entity.Country;

public class CountryDaoTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		CountryDao cdao=new CountryDaoImpl();
		Country country=new Country("JI", "Jag Asia", 3);
//		int no=cdao.create(country);
//		int no=cdao.update(country);
		int no=cdao.delete("JI");
		System.out.println(no+" row(s) affected!");
	}

}
