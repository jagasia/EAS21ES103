import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Purchase");
		int noOfPurchase=sc.nextInt();
		List<Purchase> list=new ArrayList<>();
		List<Item> itemList = Item.prefill();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		for(int i=0;i<noOfPurchase;i++)
		{
			System.out.println("Enter purchase detail "+(i+1));
			String purchaseDetail=sc.nextLine();
			if(purchaseDetail.equals(""))
				purchaseDetail=sc.nextLine();
			String[] arr = purchaseDetail.split(",");
			Purchase purchase=new Purchase();
			purchase.setId(Integer.valueOf(arr[0]));
			purchase.setCouponCode(arr[1]);
			purchase.setPurchaseDate(sdf.parse(arr[2]));
			
			System.out.println("Enter the number of Orders");
			int noOfOrders=sc.nextInt();
			for(int j=0;j<noOfOrders;j++)
			{
				String orderDetail=sc.nextLine();
				if(orderDetail.equals(""))
					orderDetail=sc.nextLine();
				String[] arr2 = orderDetail.split(",");
				Order order=new Order();
				order.setQuantity(Integer.valueOf(arr2[0]));
				String itemName=arr2[1];
				for(Item x: itemList)
				{
					if(x.getName().equals(itemName))
					{
						order.setItem(x);
						break;
					}
				}
				purchase.getOrderList().add(order);
			}
			list.add(purchase);
		}
		Purchase.computePrice(list);
		
		System.out.format("%-5s %-10s %-12s %s\n","Id","Price","Coupon Code","Purchase Date");
		for(Purchase p:list)
			System.out.format("%-5s %-10s %-12s %s\n",p.getId(),p.getPrice(),p.getCouponCode(),sdf.format(p.getPurchaseDate()));
	}
	

}
