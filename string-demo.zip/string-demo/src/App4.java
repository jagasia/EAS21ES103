import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class App4 {

	public static void main(String[] args) {
		String str="Kindly note down the builder's contact number 9898989898. Contact him on this number or 7473727187.";
//		for(int i=0;i<str.length();i++)	//for as many characters in the string
//		{
//			char c = str.charAt(i);
//			if(Character.isDigit(c))
//				System.out.print(c);
//			else
//				System.out.println();
//		}
		
//		str.matches("[0-9]+");	///this is to check if string matches the pattern or not
		Pattern p = Pattern.compile("[0-9]+");
		Matcher m = p.matcher(str);
		while(m.find())
		{
			System.out.println(m.group());
		}
		
	}

}
