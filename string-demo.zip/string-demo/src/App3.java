
public class App3 {

	public static void main(String[] args) {
		String str="education";
		StringBuilder sb=new StringBuilder(str);
		str=sb.reverse().toString();
		System.out.println(str);

		
	}

}
