
public class App2 {

	public static void main(String[] args) {
//		String str1="hello";
//		System.out.println(str1);
//		str1="world";
//		System.out.println(str1);
//		
		StringBuilder sb=new StringBuilder();
		sb.append("Hello");
		sb.append(" ");
		sb.append("world");
		System.out.println(sb);
		
//		String str=sb;	//not possible
		String str=sb.toString();		//possible
	}

}
