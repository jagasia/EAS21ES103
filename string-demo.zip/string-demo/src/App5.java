import java.util.Arrays;
import java.util.StringTokenizer;

public class App5 {

	public static void main(String[] args) {
//		String str="This is a sentence that you need to count the number of words";
//		String[] arr = str.split(" ");
//		System.out.println(arr.length);
		
//		String str="172.168.1.14";
//		String[] arr = str.split("\\.");
//		System.out.println(arr.length);
//		System.out.println(Arrays.toString(arr));
		
		String str="172.168.1.14";
		StringTokenizer st=new StringTokenizer(str,".");
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());
		}
		
		System.out.println(str.hashCode());
		str="rama";
		System.out.println(str.hashCode());
		String s="rama";
		System.out.println(s.hashCode());
	}

}
