import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class App2 {

	public static void main(String[] args) throws IOException {
		File f=new File("C:\\Users\\rjaga\\Pictures\\vada.jpg");
		int len=(int) f.length();
		byte []data=new byte[len];
		
		FileInputStream fis=new FileInputStream(f);
		fis.read(data);
		fis.close();
		
		//data is the array of bytes
		
		////write the bytes to a new location
		FileOutputStream fos=new FileOutputStream("D:\\jag\\cts\\VAMSI\\idli.jpg");
		fos.write(data);
		fos.flush();
		fos.close();
		
	}

}
