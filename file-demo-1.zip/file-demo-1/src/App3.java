import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class App3 {

	public static void main(String[] args) throws IOException {
		File f=new File("C:\\Users\\rjaga\\Pictures\\vada.jpg");
		//this time, we do not read all the bytes at a time
		//rather, we read one byte and write that byte into the destination file
		
		FileInputStream fis=new FileInputStream(f);
		FileOutputStream fos=new FileOutputStream("D:\\\\jag\\\\cts\\\\VAMSI\\\\breakfast1.jpg");
		
		
		int b;			//not an array, only 1 byte at a time we read
		while((b=fis.read())!=-1)
		{
			System.out.println("Reading...");
			fos.write(b);
		}
		fos.flush();
		fos.close();
	}

}
