import java.io.File;
import java.util.Date;

public class App1 {

	public static void main(String[] args) {
		File f=new File("D:\\Jag\\CTS\\core_java_qns_data.xml");
		System.out.println(f.length());
		System.out.println(f.getAbsolutePath());
		System.out.println(new Date(f.lastModified()));
		
	}

}
